#!/usr/bin/perl

use v5.20;
use warnings;

BEGIN { $ENV{PERL_FUTURE_NO_XS} = 1; }

do "./t/10wait_all.pl";
die $@ if $@;
